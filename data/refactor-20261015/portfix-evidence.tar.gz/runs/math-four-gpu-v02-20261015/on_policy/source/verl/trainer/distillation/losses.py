# Copyright 2025 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import torch
from tensordict import TensorDict

from verl.base_config import BaseConfig
from verl.trainer.ppo.core_algos import agg_loss, get_policy_loss_fn, kl_penalty
from verl.utils.metric import AggregationType, Metric
from verl.utils.ulysses import get_ulysses_sequence_parallel_world_size
from mirroropd.integrations.verl import bridge as mirror

MIRROR_API_VERSION = 2
from verl.workers.config import ActorConfig, DistillationConfig, DistillationLossConfig
from verl.workers.utils.losses import ppo_loss
from verl.workers.utils.padding import no_padding_2_padding

DistillationLossFn = Callable[
    [
        ActorConfig,  # actor_config
        DistillationConfig,  # distillation_config
        dict,  # model_output
        TensorDict,  # micro batch input
    ],
    tuple[torch.Tensor, dict[str, Any]],
]






def is_distillation_enabled(config: Optional[DistillationConfig]) -> bool:
    """Check if distillation is enabled based on the provided configuration."""
    if config is None:
        return False
    return config.enabled








@dataclass
class DistillationLossSettings(BaseConfig):
    """
    Settings for a distillation loss function to be registered.

    Args:
        names (str | list[str]): Name(s) to register the distillation loss function under.
        use_topk (bool): Whether the loss function uses top-k log probabilities.
        use_estimator (bool): Whether the loss function uses single-sample KL estimators.
        use_sampled_logprob (bool): Whether the loss function additionally requires the
            teacher log-probability of the sampled (rollout) token. Can only be combined
            with use_topk, e.g., for unbiased top-k + tail-correction estimators.
    """

    names: str | list[str] = field(default_factory=list)
    use_topk: bool = False
    use_estimator: bool = False
    use_sampled_logprob: bool = False

    _mutable_fields = {"names"}

    def __post_init__(self):
        self.names = [self.names] if isinstance(self.names, str) else self.names
        if sum([self.use_topk, self.use_estimator]) != 1:
            raise ValueError(
                f"Expected only one of use_estimator, use_topk, but got {self.use_estimator=}, {self.use_topk=}."
            )
        if self.use_sampled_logprob and not self.use_topk:
            raise ValueError(
                "use_sampled_logprob requires use_topk=True: the estimator mode already "
                f"provides the sampled-token teacher logprob, got {self.use_estimator=}."
            )




DISTILLATION_LOSS_REGISTRY: dict[str, DistillationLossFn] = {}
DISTILLATION_SETTINGS_REGISTRY: dict[str, DistillationLossSettings] = {}


def register_distillation_loss(
    loss_settings: DistillationLossSettings,
) -> Callable[[DistillationLossFn], DistillationLossFn]:
    """Register a distillation loss function with the given name."""

    def decorator(func: DistillationLossFn) -> DistillationLossFn:
        for name in loss_settings.names:
            if name in DISTILLATION_LOSS_REGISTRY:
                raise ValueError(f"Distillation loss function with name '{name}' is already registered.")
            DISTILLATION_LOSS_REGISTRY[name] = func
            DISTILLATION_SETTINGS_REGISTRY[name] = loss_settings
        return func

    return decorator


def get_distillation_loss_fn(loss_name: str) -> DistillationLossFn:
    """Get the distillation loss function with a given name."""
    if loss_name not in DISTILLATION_LOSS_REGISTRY:
        raise ValueError(
            f"Unsupported loss mode: {loss_name}. Supported modes are: {list(DISTILLATION_LOSS_REGISTRY.keys())}"
        )
    return DISTILLATION_LOSS_REGISTRY[loss_name]


def get_distillation_loss_settings(loss_name: str) -> DistillationLossSettings:
    """Get the distillation loss settings with a given name."""
    if loss_name not in DISTILLATION_SETTINGS_REGISTRY:
        raise ValueError(
            f"Unsupported loss mode: {loss_name}. Supported modes are: {list(DISTILLATION_SETTINGS_REGISTRY.keys())}"
        )
    return DISTILLATION_SETTINGS_REGISTRY[loss_name]


def compute_distillation_loss_range(
    distillation_losses: torch.Tensor, response_mask: torch.Tensor
) -> dict[str, Metric]:
    """Compute min and max distillation loss over valid response tokens."""
    if response_mask.is_nested:
        distillation_losses_response = distillation_losses[response_mask.bool().to_padded_tensor(False)]
    else:
        distillation_losses_response = distillation_losses[response_mask.bool()]
    return {
        "distillation/loss_min": Metric(AggregationType.MIN, distillation_losses_response.min()),
        "distillation/loss_max": Metric(AggregationType.MAX, distillation_losses_response.max()),
    }


def compute_topk_loss(
    config: ActorConfig,
    distillation_config: DistillationConfig,
    data: TensorDict,
    student_logits: torch.Tensor,
    data_format: str,
) -> torch.Tensor:
    """Compute the topk loss in logit processor.

    Returns:
    - distillation_losses: (bsz, seqlen/cp_size)
    - student_mass: (bsz, seqlen/cp_size)
    - teacher_mass: (bsz, seqlen/cp_size)
    """
    match config.strategy:
        # VeOmni uses FSDP2 internally, so its loss computation is identical to FSDP.
        case "fsdp" | "veomni":
            # import verl.trainer.distillation.fsdp.losses as fsdp_losses
            #
            # distillation_loss_fn = fsdp_losses.compute_forward_kl_topk
            import verl.trainer.distillation.fsdp.losses as fsdp_losses

            loss_mode = distillation_config.distillation_loss.loss_mode

            if loss_mode == "mirror":
                return mirror.loss_callback(student_logits, data, distillation_config, data_format,
                                            sequence_parallel_size=get_ulysses_sequence_parallel_world_size())

            if loss_mode == "reverse_kl_topk":
                distillation_loss_fn = fsdp_losses.compute_reverse_kl_topk
            elif loss_mode in ("mopd_topk", "mopd_reverse_kl_topk"):
                distillation_loss_fn = fsdp_losses.compute_mopd_reverse_kl_topk
            elif loss_mode == "taopd_reverse_kl_topk":
                distillation_loss_fn = fsdp_losses.compute_taopd_reverse_kl_topk
            elif loss_mode == "normalized_reverse_kl_topk":
                distillation_loss_fn = fsdp_losses.compute_normalized_reverse_kl_topk
            elif loss_mode in (
                "sample_corrected_ta_opd",
                "sc_ta_opd",
                "sample_corrected_reverse_kl_topk",
            ):
                distillation_loss_fn = fsdp_losses.compute_taopd_with_sg
            elif loss_mode == "unnormalized_reverse_kl_topk":
                distillation_loss_fn = fsdp_losses.compute_unnormalized_reverse_kl_topk
            else:
                raise NotImplementedError(f"Unsupported top-k distillation loss mode: {loss_mode}")

        case "megatron":
            import verl.trainer.distillation.megatron.losses as megatron_losses

            distillation_loss_fn = megatron_losses.compute_forward_kl_topk
        case _:
            raise NotImplementedError(f"Unsupported strategy: {config.strategy=}")

    outputs = distillation_loss_fn(
        student_logits=student_logits,
        teacher_topk_log_probs=data["teacher_logprobs"],
        teacher_topk_ids=data["teacher_ids"],
        config=distillation_config,
        data_format=data_format,
    )

    expected_shape = student_logits.shape[:2]
    for k, v in outputs.items():
        assert v.shape == expected_shape, f"Expected shape {expected_shape}, but got {v.shape} for {k=}."

    return outputs


def distillation_ppo_loss(
    config: ActorConfig,
    distillation_config: Optional[DistillationConfig],
    model_output: dict = None,
    data: TensorDict = None,
    dp_group=None,
    student_logits: torch.Tensor = None,
    data_format: str = "thd",
):
    """Loss function used both for logit processor and final policy loss.
    - student_logits is not None, compute the topk loss in logit processor.
    - student_logits is None, compute final policy loss.

    [split sequence across sp/cp groups]
                   |
    [model forward and output logits: (bsz, seqlen/cp_size, vocab_size/tp_size)]
                   |
    [logits processor compute topk loss: (bsz, seqlen/cp_size)]
                   |
    [all gather topk loss across sp/cp groups: (bsz, seqlen)]
                   |
    [combine topk loss with policy loss]

    Args:
        config: Actor configuration.
        distillation_config: Distillation configuration.
        model_output: Model output, including log_probs, entropy.
        data: Micro input batch, contains
          - teacher_logprobs: (bsz, seqlen, topk)
          - teacher_ids: (bsz, seqlen, topk)
        student_logits: (bsz, seqlen/cp_size, vocab_size/tp_size).
        data_format: "thd" or "bshd", models not support THD format, e.g GPT-OSS, Qwen3.5

    Returns:
    - student_logits is not None, return the topk loss tensor (bsz, seqlen/cp_size).
    - student_logits is None, return the final policy loss scalar and metrics.
    """

    # Called as logits processor
    if student_logits is not None:
        return compute_topk_loss(config, distillation_config, data, student_logits, data_format)

    # Called as final policy loss
    distillation_loss_config = distillation_config.distillation_loss
    if mirror.is_enabled(distillation_config):
        mirror.prepare_global_batch(config, data)
    distill_loss, distill_metrics = distillation_loss(config, distillation_config, model_output, data)
    if mirror.is_enabled(distillation_config):
        # MirrorOPD already supplies the complete score surrogate. Evaluating
        # a discarded PPO objective still imposes unrelated advantage/ratio
        # requirements and can produce misleading metrics or numerical errors.
        distill_metrics["distillation/loss"] = Metric(value=distill_loss, aggregation=AggregationType.SUM)
        return distill_loss, distill_metrics
    policy_loss, policy_metrics = ppo_loss(config, model_output, data, dp_group)
    if not distillation_loss_config.use_task_rewards:
        policy_loss = 0.0

    # Combine distillation with policy loss
    policy_metrics.update(distill_metrics)
    distillation_loss_coef = (
        distillation_loss_config.distillation_loss_coef if distillation_loss_config.use_task_rewards else 1.0
    )
    policy_loss += distill_loss * distillation_loss_coef
    policy_metrics["distillation/loss"] = Metric(value=distill_loss, aggregation=AggregationType.SUM)

    return policy_loss, policy_metrics


def distillation_loss(
    config: ActorConfig,
    distillation_config: DistillationConfig,
    model_output: dict,
    data: TensorDict,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """
    Compute the distillation loss and related metrics.

    Returns:
    - distillation_loss: Aggregated distillation loss scalar.
    - distillation_metrics: Dictionary of metrics.
    """
    assert distillation_config is not None
    loss_config: DistillationLossConfig = distillation_config.distillation_loss
    distillation_loss_fn = get_distillation_loss_fn(loss_config.loss_mode)
    distillation_losses, distillation_metrics = distillation_loss_fn(
        config=config,
        distillation_config=distillation_config,
        model_output=model_output,
        data=data,
    )
    response_mask = data["response_mask"]
    loss_agg_mode = config.loss_agg_mode

    distillation_metrics.update(
        compute_distillation_loss_range(distillation_losses=distillation_losses, response_mask=response_mask)
    )
    if loss_config.loss_max_clamp is not None:
        # clamping min is for k1 loss which can be negative
        distillation_losses = distillation_losses.clamp(min=-loss_config.loss_max_clamp, max=loss_config.loss_max_clamp)

    if loss_config.use_policy_gradient:
        # Use negative distillation loss as reward, as done by https://thinkingmachines.ai/blog/on-policy-distillation/.
        policy_loss_fn = get_policy_loss_fn(loss_config.policy_loss_mode)
        for k, v in config.global_batch_info.items():
            loss_config.global_batch_info[k] = v
        log_prob = no_padding_2_padding(model_output["log_probs"], data)
        old_log_prob = data["old_log_probs"]
        if old_log_prob.is_nested:
            old_log_prob = data["old_log_probs"].to_padded_tensor(0.0)
        if response_mask.is_nested:
            response_mask = response_mask.to_padded_tensor(False)
        rollout_is_weights = data.get("rollout_is_weights", None)
        distillation_loss, pg_metrics = policy_loss_fn(
            old_log_prob=old_log_prob,
            log_prob=log_prob,
            advantages=-distillation_losses.detach(),
            response_mask=response_mask,
            loss_agg_mode=loss_agg_mode,
            config=loss_config,
            rollout_is_weights=rollout_is_weights,
        )
        pg_metrics = {f"distillation/{k[len('actor/') :]}": v for k, v in pg_metrics.items()}
        distillation_metrics.update(pg_metrics)
    else:
        # Directly backpropagate distillation loss as a supervised loss, as in https://arxiv.org/abs/2306.13649.
        if response_mask.is_nested:
            response_mask = response_mask.to_padded_tensor(False)
        distillation_loss = agg_loss(
            loss_mat=distillation_losses,
            loss_mask=response_mask,
            loss_agg_mode=loss_agg_mode,
            **config.global_batch_info,
        )

    return distillation_loss, distillation_metrics



@register_distillation_loss(
    DistillationLossSettings(names=["mirror"], use_topk=True, use_sampled_logprob=True)
)
def compute_mirror_loss(config, distillation_config, model_output, data):
    return mirror.aggregate_loss(model_output, data)



@register_distillation_loss(
    DistillationLossSettings(names=["kl", "k1", "abs", "mse", "k2", "low_var_kl", "k3"], use_estimator=True)
)  # type: ignore[arg-type]
def compute_distillation_loss_reverse_kl_estimator(
    config: ActorConfig,
    distillation_config: DistillationConfig,
    model_output,
    data: TensorDict,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """
    Compute the distillation loss and related metrics using single-sample KL estimators.

    Uses the kl_penalty function from core_algos which supports various KL divergence
    estimators: "kl", "k1", "abs", "mse", "k2", "low_var_kl", "k3".

    Returns:
    - distillation_losses: (bsz, resp_len)
    - distillation_metrics: Dictionary of metrics.
    """
    student_log_probs = no_padding_2_padding(model_output["log_probs"], data)
    teacher_log_probs = no_padding_2_padding(data["teacher_logprobs"], data).squeeze(-1)
    if data["response_mask"].is_nested:
        response_mask_bool = data["response_mask"].bool().to_padded_tensor(False)
    else:
        response_mask_bool = data["response_mask"].bool()
    assert teacher_log_probs.shape == student_log_probs.shape == response_mask_bool.shape

    loss_config: DistillationLossConfig = distillation_config.distillation_loss
    distillation_losses = kl_penalty(
        logprob=student_log_probs, ref_logprob=teacher_log_probs, kl_penalty=loss_config.loss_mode
    )
    # Since k1 can be negative, log the mean absolute loss.
    metrics = {
        "distillation/abs_loss": Metric(AggregationType.MEAN, distillation_losses[response_mask_bool].abs().mean()),
    }
    return distillation_losses, metrics



@register_distillation_loss(
    DistillationLossSettings(
        names=[
            "reverse_kl_topk",
            "normalized_reverse_kl_topk",
            "unnormalized_reverse_kl_topk",
            "taopd_reverse_kl_topk",
            "mopd_topk",
            "mopd_reverse_kl_topk",
        ],
        use_topk=True,
    )
)  # type: ignore[arg-type]
def compute_reverse_kl_topk(
    config: ActorConfig,
    distillation_config: DistillationConfig,
    model_output: dict,
    data: TensorDict,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Compute forward KL distillation loss and related metrics using top-k log probabilities.

    Returns:
    - distillation_losses: (bsz, resp_len)
    - distillation_metrics: Dictionary of metrics.
    """
    # topk loss has been computed in logits processor
    distillation_losses = no_padding_2_padding(model_output["distillation_losses"], data)
    student_mass = no_padding_2_padding(model_output["student_mass"], data)
    teacher_mass = no_padding_2_padding(model_output["teacher_mass"], data)
    overlap_count = model_output.get("overlap_count")
    overlap_token_advantage = model_output.get("overlap_token_advantage")

    cov_student_log_student = model_output.get("cov_student_log_student")
    cov_student_log_teacher = model_output.get("cov_student_log_teacher")
    cov_student_minus_teacher_residual = model_output.get(
        "cov_student_minus_teacher_residual"
    )

    tail_weighted_cov = model_output.get("tail_weighted_cov")

    cov_metrics_raw = {
        "cov_student_log_student": cov_student_log_student,
        "cov_student_log_teacher": cov_student_log_teacher,
        "cov_student_minus_teacher_residual": cov_student_minus_teacher_residual,
        "tail_weighted_cov": tail_weighted_cov,
    }

    cov_metrics_padded = {}
    for key, value in cov_metrics_raw.items():
        if value is not None:
            cov_metrics_padded[key] = no_padding_2_padding(value, data)


    if overlap_count is not None and overlap_token_advantage is not None:
        overlap_count = no_padding_2_padding(overlap_count, data)
        overlap_token_advantage = no_padding_2_padding(overlap_token_advantage, data)
    if data["response_mask"].is_nested:
        response_mask_bool = data["response_mask"].bool().to_padded_tensor(False)
    else:
        response_mask_bool = data["response_mask"].bool()
    assert distillation_losses.shape == student_mass.shape == teacher_mass.shape == response_mask_bool.shape
    for key, value in cov_metrics_padded.items():
        assert value.shape == response_mask_bool.shape, (
            f"Expected shape {response_mask_bool.shape}, but got {value.shape} for {key}."
        )


    overlap_metrics = {}
    if overlap_count is not None and overlap_token_advantage is not None:
        assert overlap_count.shape == overlap_token_advantage.shape == response_mask_bool.shape
        valid_overlap_count = overlap_count[response_mask_bool]
        k = distillation_config.distillation_loss.topk
        assert k is not None
        # Diagnostics for tracking teacher/student top-k overlap in OPD, following
        # "Rethinking On-Policy Distillation of Large Language Models" (arXiv:2604.13016):
        # overlap ratio and average teacher-token KL contribution on overlapped tokens.
        overlap_metrics["distillation/overlap_ratio"] = (valid_overlap_count.float().mean() / k).item()
        overlap_position_mask = response_mask_bool & (overlap_count > 0)
        if overlap_position_mask.any():
            overlap_metrics["distillation/overlap_token_advantage"] = (
                overlap_token_advantage[overlap_position_mask].mean().item()
            )
        else:
            overlap_metrics["distillation/overlap_token_advantage"] = 0.0

    covariance_metrics = {}
    for key, value in cov_metrics_padded.items():
        valid_value = value[response_mask_bool].float()
        covariance_metrics[f"distillation/{key}"] = valid_value.mean().item()
        covariance_metrics[f"distillation/{key}_min"] = Metric(
            AggregationType.MIN, valid_value.min()
        )
        covariance_metrics[f"distillation/{key}_max"] = Metric(
            AggregationType.MAX, valid_value.max()
        )


    # Log amount of mass in the top-k log probabilities for both student and teacher.
    student_mass = student_mass[response_mask_bool]
    teacher_mass = teacher_mass[response_mask_bool]
    distillation_metrics = {
        "distillation/student_mass": student_mass.mean().item(),
        "distillation/student_mass_min": Metric(AggregationType.MIN, student_mass.min()),
        "distillation/student_mass_max": Metric(AggregationType.MAX, student_mass.max()),
        "distillation/teacher_mass": teacher_mass.mean().item(),
        "distillation/teacher_mass_min": Metric(AggregationType.MIN, teacher_mass.min()),
        "distillation/teacher_mass_max": Metric(AggregationType.MAX, teacher_mass.max()),
        **overlap_metrics,
        **covariance_metrics,
    }

    # Due to use of top-k, student and teacher distributions don't sum to 1 -> divergences can be negative.
    # distillation_losses = distillation_losses.clamp_min(0.0)

    return distillation_losses, distillation_metrics


@register_distillation_loss(
    DistillationLossSettings(
        names=[
            "sample_corrected_ta_opd",
            "sc_ta_opd",
            "sample_corrected_reverse_kl_topk",
        ],
        use_topk=True,
        use_sampled_logprob=True,
    )
)
def compute_sample_corrected_ta_opd_loss(config, distillation_config, model_output, data):
    """Compute sample-corrected TA-OPD from TA-OPD with stop-gradient."""
    del config
    import verl.trainer.distillation.fsdp.losses as fsdp_losses

    taopd_with_sg = no_padding_2_padding(model_output["taopd_with_sg"], data)
    student_mass = no_padding_2_padding(model_output["student_mass"], data)
    teacher_mass = no_padding_2_padding(model_output["teacher_mass"], data)
    student_log_p_tail = no_padding_2_padding(model_output["student_log_p_tail"], data)
    teacher_log_q_tail = no_padding_2_padding(model_output["teacher_log_q_tail"], data)
    overlap_count = no_padding_2_padding(model_output["overlap_count"], data)
    overlap_token_advantage = no_padding_2_padding(model_output["overlap_token_advantage"], data)
    student_logp_y = no_padding_2_padding(model_output["log_probs"], data)
    # In direct-loss mode this correction is the only off-policy weighting.
    # In policy-gradient mode the outer PPO objective already applies the
    # current/old ratio, so passing it here would double-weight the sampled
    # correction.
    behavior_logp_y = (
        data.get("old_log_probs", None)
        if not distillation_config.distillation_loss.use_policy_gradient
        else None
    )
    if not distillation_config.distillation_loss.use_policy_gradient and behavior_logp_y is None:
        raise KeyError(
            "sample_corrected_ta_opd requires data['old_log_probs'] in direct-loss mode. "
            "It should be populated by main_ppo_sync._compute_old_log_prob before actor updates."
        )
    if behavior_logp_y is not None and behavior_logp_y.is_nested:
        behavior_logp_y = behavior_logp_y.to_padded_tensor(0.0)
    behavior_logp_y = behavior_logp_y.detach()

    teacher_logp_y = no_padding_2_padding(data["teacher_sampled_logprob"], data).squeeze(-1)
    teacher_ids = no_padding_2_padding(data["teacher_ids"], data)
    responses = data["responses"]
    sampled_in_topk = (teacher_ids == responses.unsqueeze(-1)).any(dim=-1)

    losses = fsdp_losses.sample_corrected_ta_opd(
        taopd_with_sg=taopd_with_sg,
        student_logp_y=student_logp_y,
        teacher_logp_y=teacher_logp_y,
        student_log_p_tail=student_log_p_tail,
        teacher_log_q_tail=teacher_log_q_tail,
        sampled_in_topk=sampled_in_topk,
        behavior_logp_y=behavior_logp_y,
    )

    response_mask = data["response_mask"]
    response_mask = response_mask.bool().to_padded_tensor(False) if response_mask.is_nested else response_mask.bool()
    valid = response_mask
    sampled_outside_topk = (~sampled_in_topk) & valid
    sample_correction = (losses - taopd_with_sg).detach()
    assert overlap_count.shape == overlap_token_advantage.shape == valid.shape

    topk = distillation_config.distillation_loss.topk
    assert topk is not None
    valid_overlap_count = overlap_count[valid]
    overlap_metrics = {
        "distillation/overlap_ratio": (valid_overlap_count.float().mean() / topk).item()
    }
    overlap_position_mask = valid & (overlap_count > 0)
    if overlap_position_mask.any():
        overlap_metrics["distillation/overlap_token_advantage"] = (
            overlap_token_advantage[overlap_position_mask].mean().item()
        )
    else:
        overlap_metrics["distillation/overlap_token_advantage"] = 0.0

    return losses, {
        "distillation/sampled_outside_topk_frac": Metric(
            AggregationType.MEAN, sampled_outside_topk.float()[valid].mean()
        ),
        "distillation/sample_correction": Metric(
            AggregationType.MEAN, sample_correction[valid].mean()
        ),
        "distillation/student_mass": Metric(AggregationType.MEAN, student_mass[valid].mean()),
        "distillation/teacher_mass": Metric(AggregationType.MEAN, teacher_mass[valid].mean()),
        **overlap_metrics,
    }
