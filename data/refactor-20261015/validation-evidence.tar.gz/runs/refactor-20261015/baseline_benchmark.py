import gc
import hashlib
import json
import os
import statistics
import time
from pathlib import Path

import torch

from mirroropd.training.cache import build_mirror_opd_cache_from_full_logits
from mirroropd.training.losses import compute_mirror_opd_token_loss
from training.gpu_exclusive import gpu_processes
from training.power_implementation_suite import acquire_lease

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
source = root / 'data/oneshot-effective-time-20261012/seed-42/rank-0.pt'
manifest = json.loads((source.parent / 'manifest.json').read_text())
artifact = torch.load(source, map_location='cpu', weights_only=False)
sequence = artifact['sequences'][0]
count = min(128, len(sequence['selected']))
selected = sequence['selected'][:count].clone()
q = sequence['q_logp_bf16'][:count].float().clone()
t = sequence['teacher_logp'][:count].float().clone()
q -= q.logsumexp(-1, keepdim=True)
t -= t.logsumexp(-1, keepdim=True)
actions = sequence['ids'][sequence['start'] + 1 + selected].clone()
inputs = {'q': q, 't': t, 'actions': actions, 'selected': selected,
          'source_sha256': manifest['rank_sha256']['0'], 'source': str(source)}
torch.save(inputs, output / 'benchmark-inputs.pt')
del artifact, sequence
gc.collect()
if any(d['pids'] or d['memory_mib'] > 16 for d in gpu_processes().values()):
    raise RuntimeError('Physical GPUs 0--3 are not idle')
lease = acquire_lease(root, output)
results = []
try:
    for n in (16, count):
        qgpu, tgpu, agpu = q[:n].cuda(), t[:n].cuda(), actions[:n].cuda()
        for method in ('opd_onpolicy', 'mdpo', 'bpo'):
            variants = [('topj_tail', 'sampled'), ('full_vocab', 'sampled')]
            if method != 'opd_onpolicy':
                variants.append(('full_vocab', 'full_vocab'))
            for center, integration in variants:
                lease.heartbeat()
                cache = build_mirror_opd_cache_from_full_logits(
                    qgpu, tgpu, agpu, torch.ones_like(agpu, dtype=torch.bool), 16,
                    center_mode=center, kappa=0.5, eta=0.2,
                )
                z = qgpu.clone().requires_grad_()
                if method != 'opd_onpolicy':
                    z.data[:, 0] += 0.2
                def step():
                    z.grad = None
                    fields = compute_mirror_opd_token_loss(
                        z, agpu, cache['mirror_anchor_ids'], cache['mirror_anchor_head_log_probs'],
                        cache['mirror_anchor_tail_log_prob'], cache['mirror_anchor_action_log_prob'],
                        cache['mirror_teacher_action_log_prob'], cache['mirror_teacher_center'],
                        method, 0.2,
                        teacher_head_log_probs=cache['mirror_teacher_head_log_probs'],
                        teacher_tail_log_prob=cache['mirror_teacher_tail_log_prob'],
                        teacher_topk_ids=cache['mirror_teacher_topk_ids'],
                        full_anchor_log_probs=cache.get('mirror_full_anchor_log_probs'),
                        full_teacher_log_probs=cache.get('mirror_full_teacher_log_probs'),
                        kappa=0.5, action_mode=integration,
                    )
                    fields['distillation_losses'].mean().backward()
                    return fields
                for _ in range(3):
                    step()
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                timings = []
                for _ in range(10):
                    start, stop = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                    start.record()
                    fields = step()
                    stop.record()
                    stop.synchronize()
                    timings.append(start.elapsed_time(stop))
                key = f'{n}-{method}-{center}-{integration}'
                torch.save(z.grad.cpu(), output / (key + '-gradient.pt'))
                results.append({'prefixes': n, 'vocab': q.shape[-1], 'algorithm': method,
                    'center': center, 'integration': integration, 'diagnostics': 'full',
                    'median_ms': statistics.median(timings), 'min_ms': min(timings),
                    'peak_allocated_bytes': torch.cuda.max_memory_allocated(),
                    'loss_mean': fields['distillation_losses'].mean().item(),
                    'gradient_norm': z.grad.norm().item()})
                (output / 'baseline-benchmark.json').write_text(json.dumps(results, indent=2) + '\n')
                del fields, z, cache
                gc.collect()
                torch.cuda.empty_cache()
        del qgpu, tgpu, agpu
finally:
    lease.release()
print(json.dumps({'cases': len(results), 'input_prefixes': count, 'cuda_visible_devices': os.environ['CUDA_VISIBLE_DEVICES']}))
