"""One persisted execution identity for events, W&B and local artifacts."""

import json
import uuid
from pathlib import Path

from mirroropd.runtime.artifacts import atomic_json


def execution_identity(directory, job, *, group=None, run_id=None):
    """Create once in an exclusively owned run directory; verify repeated reads.

    Names describe conditions; run IDs distinguish executions even when two
    directories have the same basename. Config IDs continue to describe Jobs.
    """
    path = Path(directory) / "identity.json"
    conditions = {
        "algorithm": job.objective.algorithm,
        "seed": job.training.seed,
        "job_name": job.name,
    }
    if path.exists():
        value = json.loads(path.read_text())
        if value.get("schema_version") != 2 or any(
            value.get(key) != item for key, item in conditions.items()
        ):
            raise ValueError("Execution identity does not match the requested Job")
        return value
    run_id = run_id or uuid.uuid4().hex
    value = {
        "schema_version": 2,
        "run_id": run_id,
        "name": f"{job.name}-{job.objective.algorithm}-s{job.training.seed}-{run_id[:8]}",
        "group": job.logging.wandb.group or group or job.name,
        **conditions,
    }
    atomic_json(path, value)
    return value


def run_budget(job):
    """Input-free counts, with token limits explicitly marked as upper bounds."""
    evaluation_rounds = int(job.evaluation.before_training) + len(
        {
            *range(job.evaluation.every, job.training.outer_steps + 1, job.evaluation.every),
            job.training.outer_steps,
        }
    )
    sequences = (
        job.training.outer_steps * job.training.batch_size * job.training.responses_per_prompt
    )
    return {
        "outer_steps": job.training.outer_steps,
        "optimizer_updates": job.training.outer_steps * job.training.inner_steps,
        "training_sequences": sequences,
        "training_response_tokens_upper_bound": sequences * job.training.response_tokens,
        "evaluation_rounds": evaluation_rounds,
        "samples_per_question": job.evaluation.samples_per_question,
        "question_limit": job.evaluation.question_limit,
    }
