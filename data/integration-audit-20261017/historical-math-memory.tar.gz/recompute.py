from pathlib import Path
import json,collections,datetime,hashlib,io,tarfile,gzip,sys
from mirroropd.runtime.provenance import verify_snapshot
root=Path.cwd();run=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'runs/math-four-gpu-v02-20261015-attempt-02/on_policy';record=root/'runs/integration-audit-20261017'
verify_snapshot(run/'source')
samples=[json.loads(x) for x in (run/'gpu.jsonl').read_text().splitlines()]
rows=[]
for p in (run/'events').glob('*.jsonl'):rows.extend(json.loads(x) for x in p.read_text().splitlines())
pending={};spans=collections.defaultdict(list)
for row in sorted(rows,key=lambda x:(x['producer_id'],x['sequence'])):
    if row['source']!='driver':continue
    key=(row['producer_id'],row['payload'].get('phase'))
    if row['event']=='phase.started':
        assert key not in pending;pending[key]=row
    elif row['event']=='phase.completed':
        start=pending.pop(key)
        spans[key[1]].append((datetime.datetime.fromisoformat(start['time_utc']).timestamp(),datetime.datetime.fromisoformat(row['time_utc']).timestamp()))
    elif row['event']=='phase.failed':
        pending.pop(key,None)
summary=[]
for phase,intervals in spans.items():
    matching=[s for s in samples if any(a<=s['time_unix']<=b for a,b in intervals)]
    if not matching:continue
    maxima={g:max(s['devices'][g]['memory_mib'] for s in matching) for g in ['0','1','2','3']}
    summary.append({'phase':phase,'completed_spans':len(intervals),'samples':len(matching),'per_gpu_max_mib':maxima,'per_gpu_max_GiB':{g:v/1024 for g,v in maxima.items()},'sampled_max_any_gpu_GiB':max(maxima.values())/1024,'sampled_max_simultaneous_four_gpu_sum_GiB':max(sum(d['memory_mib'] for d in s['devices'].values()) for s in matching)/1024})
if '--summary-only' in sys.argv:
    print(json.dumps({'source':json.loads((run/'run.json').read_text()),'phases':summary},indent=2));raise SystemExit(0)
files=[run/n for n in ['job.json','run.json','inputs.json','backend.yaml','gpu.jsonl']]
files+=sorted((run/'events').glob('*.jsonl'))
files+=[f for f in sorted((run/'source').rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc']
files+=[Path(__file__).resolve()];buf=io.BytesIO();index=[]
with tarfile.open(fileobj=buf,mode='w') as t:
    for p in files:
        name='recompute.py' if p.name=='historical-memory.py' else str(p.relative_to(run))
        b=p.read_bytes();m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b));index.append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
raw=buf.getvalue();archive=root/'data/integration-audit-20261017/historical-math-memory.tar.gz';archive.write_bytes(gzip.compress(raw,mtime=0))
evidence={'archive':str(archive.relative_to(root)),'restored_path':'data/integration-audit-20261017/historical-math-memory.tar','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_bytes':archive.stat().st_size,'files':index}
(root/'data/integration-audit-20261017/historical-files.json').write_text(json.dumps(evidence,indent=2)+'\n')
result={'source':json.loads((run/'run.json').read_text()),'job':json.loads((run/'job.json').read_text()),'source_bytes_verified':True,'completed_training_phases':50,'run_completion':'orphaned during final evaluation; 50 completed optimization spans, ten completed evaluation spans used here','measurement':'per-device NVML samples; phase maxima over completed driver spans, not worker CUDA allocated peaks; sampling may miss instantaneous peaks','sample_count':len(samples),'phases':summary,'unclosed_driver_spans':[k[1] for k in pending],'evidence':{k:v for k,v in evidence.items() if k!='files'}}
(root/'results/memory-audit-20261017/historical-math-memory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'phases':summary,'archive_bytes':archive.stat().st_size},indent=2))
