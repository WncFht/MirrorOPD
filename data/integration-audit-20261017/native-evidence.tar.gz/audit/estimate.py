import json,pathlib
from mirroropd.core.config import Objective,Estimator
from mirroropd.runtime.memory import cache_capacity
P=1777088000;V=151665;Vp=151936;D=4;B=64;R=7168;H=1536;L=28;kvh=2;hd=128
MiB=2**20;GiB=2**30
terms={'student_master':4*P/D,'student_gradient':4*P/D,'adam_moments':8*P/D,'actor_states_total':16*P/D,'teacher_shard':2*P/D,'rollout_replica':2*P,'head_gradient_fp32':4*Vp*H,'current_micro_logits_bf16':2*R*V,'current_micro_fp32_distribution':4*R*V,'token_tile_logits_bf16':2*64*V,'token_tile_fp32_distribution':4*64*V,'original_teacher_logits_bf16_4gpu':2*16*8192*Vp,'original_teacher_fp32_upcast_4gpu':4*16*7168*Vp,'original_dynamic_actor_logits_bf16':2*32768*Vp,'original_dynamic_actor_fp32_upcast':4*32768*Vp,'original_teacher_micro1_logits_bf16':2*8192*Vp,'original_teacher_micro1_fp32_upcast':4*7168*Vp}
kv=2*L*kvh*hd*2
terms.update(kv_per_token=kv,kv_one_train_paper=kv*8192,kv_one_train_current=kv*9216,kv_one_eval_paper=kv*32768,kv_one_eval_current=kv*35840,kv_16_eval_current=kv*35840*16,kv_32_eval_current=kv*35840*32)
terms['original_teacher_logit_and_upcast_lower_bound']=terms['original_teacher_logits_bf16_4gpu']+terms['original_teacher_fp32_upcast_4gpu']
caches={}
for a,c,i,d in [('bpo','topj_tail','sampled','full'),('mdpo','topj_tail','sampled','none'),('bpo','full','full','none'),('mdpo','full','full','none')]:
 o=Objective(algorithm=a,estimator=Estimator(c,i,16),diagnostics=d);caches[f'{a}-{c}-{i}-{d}']=cache_capacity(o,prefixes=B*R,vocab_size=V,sequence_slots=B*9216)
result={'assumptions':{'parameters_each':P,'legal_vocab':V,'padded_vocab':Vp,'global_batch':B,'dp':D,'train_response_cap':R,'current_train_prompt_cap':2048,'paper_train_prompt_cap':1024,'bf16_bytes':2,'fp32_bytes':4,'teacher_default_microbatch':24,'effective_teacher_microbatch_4gpu':16,'original_precision_commit':'6b6b1782cc3f04749dd077de19353f839f6bc048','board_mib':81559},'terms':{k:{'bytes':int(v),'GiB':v/GiB,'MiB':v/MiB} for k,v in terms.items()},'cache_capacities':caches,'rollout_engine_budget_GiB':{'current_fraction_0.25':81559/1024*.25,'original_fraction_0.75':81559/1024*.75}}
p=pathlib.Path('results/memory-audit-20261017/four-gpu-estimates.json');p.write_text(json.dumps(result,indent=2)+'\n')
for k in ['actor_states_total','original_teacher_logit_and_upcast_lower_bound','original_teacher_micro1_logits_bf16','original_teacher_micro1_fp32_upcast','kv_16_eval_current','kv_32_eval_current']:print(k,result['terms'][k]['GiB'])
