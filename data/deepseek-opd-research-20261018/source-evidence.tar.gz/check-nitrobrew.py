"""CPU semantic checks of pinned Nitrobrew with compile decorators disabled."""
import importlib.util
import itertools
import json
from pathlib import Path
from unittest.mock import patch
import torch


def load_reference(root):
    source = Path(root) / 'sources/nitrobrew/nitrobrew.py'
    spec = importlib.util.spec_from_file_location('audited_nitrobrew', source)
    module = importlib.util.module_from_spec(spec)
    with patch.object(torch, 'compile', lambda fn: fn):
        spec.loader.exec_module(module)
    return module


def check_case(module, direction, temperature, chunk):
    torch.manual_seed(220)
    xs = (torch.randn(2, 5, 7, dtype=torch.float32, device="cpu") / 3).requires_grad_()
    xt = (torch.randn(2, 5, 11, dtype=torch.float32, device="cpu") / 3).requires_grad_()
    ws = (torch.randn(37, 7, dtype=torch.float32, device="cpu") / 3).requires_grad_()
    wt = (torch.randn(37, 11, dtype=torch.float32, device="cpu") / 3).requires_grad_()
    result = getattr(module, direction + '_kl')(
        xs, xt, ws, wt, temperature=temperature, reduction='none', chunk_V=chunk
    )
    lp = ((xs @ ws.T) / temperature).log_softmax(-1)
    lq = ((xt.detach() @ wt.detach().T) / temperature).log_softmax(-1)
    expected = (lq.exp() * (lq - lp)).sum(-1) if direction == 'forward' else (lp.exp() * (lp - lq)).sum(-1)
    upstream = torch.tensor([[1., 0., .2, -.3, .9], [.6, -.2, 1.2, 0., .7]], dtype=torch.float32, device="cpu")
    got = torch.autograd.grad((result * upstream).sum(), (xs, ws, xt, wt), allow_unused=True, retain_graph=True)
    want = torch.autograd.grad((expected * upstream).sum(), (xs, ws))
    torch.testing.assert_close(result, expected, atol=3e-6, rtol=3e-5)
    for actual, reference in zip(got[:2], want):
        torch.testing.assert_close(actual, reference, atol=3e-6, rtol=3e-5)
    assert got[2] is None and got[3] is None
    return {
        'direction': direction, 'temperature': temperature, 'vocab_chunk': chunk,
        'loss_max_abs': (result - expected).abs().max().item(),
        'gradient_max_abs': max((a - b).abs().max().item() for a, b in zip(got[:2], want)),
        'teacher_gradients': False,
    }


def main():
    root = Path(__file__).resolve().parent
    module = load_reference(root)
    torch.set_num_threads(1)
    records = [check_case(module, direction, temperature, chunk)
               for direction, temperature, chunk in itertools.product(
                   ['forward', 'reverse'], [.7, 1., 2.], [1, 7, 64])]
    q = torch.tensor([.5, .3, .2], dtype=torch.float64)
    teacher = torch.tensor([.4, .1, .5], dtype=torch.float64)
    eta, kappa = .2, .5
    raw = torch.logaddexp(
        torch.log(torch.tensor(1 - eta, dtype=torch.float64)) + kappa * q.log(),
        torch.log(torch.tensor(eta, dtype=torch.float64)) + kappa * teacher.log(),
    ) / kappa
    reward = (raw - q.log()) / eta
    result = {
        'scope': 'CPU FP32 source semantics only; compile decorators disabled; no CUDA, performance or distributed integration claim',
        'source_commit': '17f6f16b7451929209ac495c6b0ea0fcc4d0cedc',
        'cases': records, 'passed': len(records),
        'max_loss_absolute_error': max(x['loss_max_abs'] for x in records),
        'max_gradient_absolute_error': max(x['gradient_max_abs'] for x in records),
        'power_center_example': {
            'q': q.tolist(), 'teacher': teacher.tolist(), 'kappa': kappa, 'eta': eta,
            'K_T': -(q * reward).sum().item(),
            'ordinary_KL_q_teacher': (q * (q.log() - teacher.log())).sum().item(),
        },
        'cuda_initialized': torch.cuda.is_initialized(),
    }
    assert not result['cuda_initialized']
    (root / 'cpu-semantic-check.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}, indent=2))


if __name__ == '__main__':
    main()
