# Copyright 2026 Tilde Research
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Nitrobrew: fused, constant-memory KL divergence from hidden states.

Computes KL divergence between student and teacher softmax distributions.

Supports D_student !+ D_teacher via separate hidden states and unembed weights.
"""

from typing import Tuple

import torch


# ---------------------------------------------------------------------------
# Forward KL: KL(q ‖ p)
# ---------------------------------------------------------------------------

@torch.compile
def _forward_kl_fwd_chunked(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float,
    chunk_V: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Chunked forward pass for KL(q ‖ p).

    Args:
        xs: [N, D_s] student hidden states (flattened B*T)
        xt: [N, D_t] teacher hidden states
        ws: [V, D_s] student unembed weight
        wt: [V, D_t] teacher unembed weight
        temperature: softmax temperature
        chunk_V: vocab chunk size

    Returns:
        kl, log_Z_p, log_Z_q: each [N] in float32.

    Online softmax accumulators (teacher-weighted):
        S_q = Σ exp(z_q − m_q)           partition function (unnormalized)
        T_q = Σ exp(z_q − m_q) * z_q     for E_q[z_q]
        U_q = Σ exp(z_q − m_q) * z_p     for E_q[z_p]

    Final: KL(q ‖ p) = (T_q − U_q) / S_q − log Z_q + log Z_p
    """
    N = xs.shape[0]
    V = ws.shape[0]
    inv_t = 1.0 / temperature

    # Student accumulators
    m_p = torch.full((N,), float("-inf"), dtype=torch.float32, device=xs.device)
    s_p = torch.zeros(N, dtype=torch.float32, device=xs.device)

    # Teacher accumulators
    m_q = torch.full((N,), float("-inf"), dtype=torch.float32, device=xs.device)
    s_q = torch.zeros(N, dtype=torch.float32, device=xs.device)
    t_q = torch.zeros(N, dtype=torch.float32, device=xs.device)
    u_q = torch.zeros(N, dtype=torch.float32, device=xs.device)

    for v0 in range(0, V, chunk_V):
        v1 = min(v0 + chunk_V, V)

        zp_tile = torch.mm(xs, ws[v0:v1].T).float().mul_(inv_t)
        zq_tile = torch.mm(xt, wt[v0:v1].T).float().mul_(inv_t)

        # Student partition: online max-sum
        tile_m_p = zp_tile.max(dim=1).values
        new_m_p = torch.maximum(m_p, tile_m_p)
        alpha_p = (m_p - new_m_p).exp_()
        s_p.mul_(alpha_p)
        s_p.add_((zp_tile - new_m_p.unsqueeze(1)).exp_().sum(dim=1))
        m_p = new_m_p

        # Teacher: online max-sum + weighted sums
        tile_m_q = zq_tile.max(dim=1).values
        new_m_q = torch.maximum(m_q, tile_m_q)
        alpha_q = (m_q - new_m_q).exp_()
        s_q.mul_(alpha_q)
        t_q.mul_(alpha_q)
        u_q.mul_(alpha_q)
        exp_tile = (zq_tile - new_m_q.unsqueeze(1)).exp_()
        s_q.add_(exp_tile.sum(dim=1))
        t_q.add_((exp_tile * zq_tile).sum(dim=1))
        u_q.add_((exp_tile * zp_tile).sum(dim=1))
        m_q = new_m_q

    log_Z_p = m_p + s_p.log()
    log_Z_q = m_q + s_q.log()
    kl = (t_q - u_q) / s_q - log_Z_q + log_Z_p

    return kl, log_Z_p, log_Z_q


@torch.compile
def _forward_kl_bwd_chunked(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    log_Z_p: torch.Tensor,
    log_Z_q: torch.Tensor,
    do: torch.Tensor,
    temperature: float,
    chunk_V: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Chunked backward for forward KL..

    grad KL = −q(v) + p(v)  ->  gradient pushes student toward teacher.

    Returns:
        d_xs: [N, D_s] gradient w.r.t. student hidden states
        d_ws: [V, D_s] gradient w.r.t. student unembed
    """
    N, D_s = xs.shape
    V = ws.shape[0]
    inv_t = 1.0 / temperature
    in_dtype = xs.dtype

    d_xs = torch.zeros(N, D_s, dtype=torch.float32, device=xs.device)
    d_ws = torch.empty(V, D_s, dtype=torch.float32, device=xs.device)

    do_scaled = (do * inv_t).unsqueeze(1)  # [N, 1]

    for v0 in range(0, V, chunk_V):
        v1 = min(v0 + chunk_V, V)
        ws_c = ws[v0:v1]
        wt_c = wt[v0:v1]

        zp_c = torch.mm(xs, ws_c.T).float().mul_(inv_t)
        zq_c = torch.mm(xt, wt_c.T).float().mul_(inv_t)

        p = (zp_c - log_Z_p.unsqueeze(1)).exp_()
        q = (zq_c - log_Z_q.unsqueeze(1)).exp_()

        g = (p - q) * do_scaled

        g_native = g.to(in_dtype)
        d_xs += torch.mm(g_native, ws_c).float()
        d_ws[v0:v1] = torch.mm(g_native.T, xs).float()

    return d_xs, d_ws


# ---------------------------------------------------------------------------
# Reverse KL: KL(p ‖ q)
# ---------------------------------------------------------------------------

@torch.compile
def _reverse_kl_fwd_chunked(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float,
    chunk_V: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Chunked forward pass for KL(p ‖ q).

    Online softmax accumulators (student-weighted):
        S_p = sum_p exp(z_p − m_p)           unnormalized partition function
        T_p = sum_p exp(z_p − m_p) * z_p     for E_p[z_p]
        U_p = sum_p exp(z_p − m_p) * z_q     for E_p[z_q]

    Final: KL(p ‖ q) = (T_p − U_p) / S_p − log Z_p + log Z_q

    Returns:
        kl, log_Z_p, log_Z_q: each [N] in float32.
    """
    N = xs.shape[0]
    V = ws.shape[0]
    inv_t = 1.0 / temperature

    # Student accumulators
    m_p = torch.full((N,), float("-inf"), dtype=torch.float32, device=xs.device)
    s_p = torch.zeros(N, dtype=torch.float32, device=xs.device)
    t_p = torch.zeros(N, dtype=torch.float32, device=xs.device)
    u_p = torch.zeros(N, dtype=torch.float32, device=xs.device)

    # Teacher accumulators
    m_q = torch.full((N,), float("-inf"), dtype=torch.float32, device=xs.device)
    s_q = torch.zeros(N, dtype=torch.float32, device=xs.device)

    for v0 in range(0, V, chunk_V):
        v1 = min(v0 + chunk_V, V)

        zp_tile = torch.mm(xs, ws[v0:v1].T).float().mul_(inv_t)
        zq_tile = torch.mm(xt, wt[v0:v1].T).float().mul_(inv_t)

        # Student: online max-sum + weighted sums
        tile_m_p = zp_tile.max(dim=1).values
        new_m_p = torch.maximum(m_p, tile_m_p)
        alpha_p = (m_p - new_m_p).exp_()
        s_p.mul_(alpha_p)
        t_p.mul_(alpha_p)
        u_p.mul_(alpha_p)
        exp_tile = (zp_tile - new_m_p.unsqueeze(1)).exp_()
        s_p.add_(exp_tile.sum(dim=1))
        t_p.add_((exp_tile * zp_tile).sum(dim=1))
        u_p.add_((exp_tile * zq_tile).sum(dim=1))
        m_p = new_m_p

        # Teacher partition: online max-sum
        tile_m_q = zq_tile.max(dim=1).values
        new_m_q = torch.maximum(m_q, tile_m_q)
        alpha_q = (m_q - new_m_q).exp_()
        s_q.mul_(alpha_q)
        s_q.add_((zq_tile - new_m_q.unsqueeze(1)).exp_().sum(dim=1))
        m_q = new_m_q

    log_Z_p = m_p + s_p.log()
    log_Z_q = m_q + s_q.log()
    kl = (t_p - u_p) / s_p - log_Z_p + log_Z_q

    return kl, log_Z_p, log_Z_q


@torch.compile
def _reverse_kl_bwd_chunked(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    log_Z_p: torch.Tensor,
    log_Z_q: torch.Tensor,
    kl: torch.Tensor,
    do: torch.Tensor,
    temperature: float,
    chunk_V: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Chunked backward for reverse KL.

    grad KL = p(v) * [log p(v) − log q(v) − KL]

    Returns:
        d_xs: [N, D_s] gradient w.r.t. student hidden states
        d_ws: [V, D_s] gradient w.r.t. student unembed
    """
    N, D_s = xs.shape
    V = ws.shape[0]
    inv_t = 1.0 / temperature
    in_dtype = xs.dtype

    d_xs = torch.zeros(N, D_s, dtype=torch.float32, device=xs.device)
    d_ws = torch.empty(V, D_s, dtype=torch.float32, device=xs.device)

    do_scaled = (do * inv_t).unsqueeze(1)  # [N, 1]

    for v0 in range(0, V, chunk_V):
        v1 = min(v0 + chunk_V, V)
        ws_c = ws[v0:v1]
        wt_c = wt[v0:v1]

        zp_c = torch.mm(xs, ws_c.T).float().mul_(inv_t)
        zq_c = torch.mm(xt, wt_c.T).float().mul_(inv_t)

        log_p = zp_c - log_Z_p.unsqueeze(1)
        log_q = zq_c - log_Z_q.unsqueeze(1)
        p = log_p.exp()

        g = p * (log_p - log_q - kl.unsqueeze(1)) * do_scaled

        g_native = g.to(in_dtype)
        d_xs += torch.mm(g_native, ws_c).float()
        d_ws[v0:v1] = torch.mm(g_native.T, xs).float()

    return d_xs, d_ws


# ---------------------------------------------------------------------------
# Autograd wrappers
# ---------------------------------------------------------------------------

class _ForwardKL(torch.autograd.Function):
    """KL(q ‖ p)"""

    @staticmethod
    def forward(
        ctx,
        xs: torch.Tensor,
        xt: torch.Tensor,
        ws: torch.Tensor,
        wt: torch.Tensor,
        temperature: float,
        reduction: str,
        chunk_V: int,
    ) -> torch.Tensor:
        xs = xs.contiguous()
        xt = xt.contiguous()
        ws = ws.contiguous()
        wt = wt.contiguous()

        B, T, D_s = xs.shape
        N = B * T

        xs_flat = xs.view(N, D_s)
        xt_flat = xt.view(N, xt.shape[-1])

        kl_flat, log_Z_p, log_Z_q = _forward_kl_fwd_chunked(
            xs_flat, xt_flat, ws, wt, temperature, chunk_V,
        )
        kl = kl_flat.view(B, T)

        ctx.save_for_backward(xs, xt, ws, wt, log_Z_p.view(B, T), log_Z_q.view(B, T))
        ctx.temperature = temperature
        ctx.reduction = reduction
        ctx.chunk_V = chunk_V

        if reduction == "mean":
            return kl.mean()
        if reduction == "sum":
            return kl.sum()
        return kl

    @staticmethod
    def backward(ctx, grad_output):
        xs, xt, ws, wt, log_Z_p, log_Z_q = ctx.saved_tensors
        B, T, D_s = xs.shape
        N = B * T

        if ctx.reduction == "none":
            do = grad_output.float().contiguous().view(N)
        elif ctx.reduction == "mean":
            do = torch.full((N,), grad_output.item() / N,
                            dtype=torch.float32, device=xs.device)
        else:
            do = torch.full((N,), grad_output.item(),
                            dtype=torch.float32, device=xs.device)

        d_xs, d_ws = _forward_kl_bwd_chunked(
            xs.view(N, D_s).contiguous(),
            xt.view(N, xt.shape[-1]).contiguous(),
            ws, wt,
            log_Z_p.view(N).contiguous(),
            log_Z_q.view(N).contiguous(),
            do, ctx.temperature, ctx.chunk_V,
        )

        return (
            d_xs.view(B, T, D_s).to(xs.dtype),
            None,
            d_ws.to(ws.dtype),
            None,
            None,
            None,
            None,
        )


class _ReverseKL(torch.autograd.Function):
    """KL(p ‖ q)"""

    @staticmethod
    def forward(
        ctx,
        xs: torch.Tensor,
        xt: torch.Tensor,
        ws: torch.Tensor,
        wt: torch.Tensor,
        temperature: float,
        reduction: str,
        chunk_V: int,
    ) -> torch.Tensor:
        xs = xs.contiguous()
        xt = xt.contiguous()
        ws = ws.contiguous()
        wt = wt.contiguous()

        B, T, D_s = xs.shape
        N = B * T

        xs_flat = xs.view(N, D_s)
        xt_flat = xt.view(N, xt.shape[-1])

        kl_flat, log_Z_p, log_Z_q = _reverse_kl_fwd_chunked(
            xs_flat, xt_flat, ws, wt, temperature, chunk_V,
        )
        kl = kl_flat.view(B, T)

        ctx.save_for_backward(
            xs, xt, ws, wt,
            log_Z_p.view(B, T), log_Z_q.view(B, T), kl,
        )
        ctx.temperature = temperature
        ctx.reduction = reduction
        ctx.chunk_V = chunk_V

        if reduction == "mean":
            return kl.mean()
        if reduction == "sum":
            return kl.sum()
        return kl

    @staticmethod
    def backward(ctx, grad_output):
        xs, xt, ws, wt, log_Z_p, log_Z_q, kl = ctx.saved_tensors
        B, T, D_s = xs.shape
        N = B * T

        if ctx.reduction == "none":
            do = grad_output.float().contiguous().view(N)
        elif ctx.reduction == "mean":
            do = torch.full((N,), grad_output.item() / N,
                            dtype=torch.float32, device=xs.device)
        else:
            do = torch.full((N,), grad_output.item(),
                            dtype=torch.float32, device=xs.device)

        d_xs, d_ws = _reverse_kl_bwd_chunked(
            xs.view(N, D_s).contiguous(),
            xt.view(N, xt.shape[-1]).contiguous(),
            ws, wt,
            log_Z_p.view(N).contiguous(),
            log_Z_q.view(N).contiguous(),
            kl.view(N).contiguous(),
            do, ctx.temperature, ctx.chunk_V,
        )

        return (
            d_xs.view(B, T, D_s).to(xs.dtype),
            None,
            d_ws.to(ws.dtype),
            None,
            None,
            None,
            None,
        )


# ---------------------------------------------------------------------------
# Public
# ---------------------------------------------------------------------------

def forward_kl(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float = 1.0,
    reduction: str = "none",
    chunk_V: int = 4096,
) -> torch.Tensor:
    """KL(q ‖ p)

    Computes the full-vocabulary forward KL divergence without materializing
    [B, T, V] logit tensors. Memory is O(B*T*chunk_V) per chunk iteration.

    Gradients flow through xs (student hidden states) and ws (student unembed)
    only. Teacher tensors xt and wt are treated as constants.

    Args:
        xs: [B, T, D_s]  student hidden states
        xt: [B, T, D_t]  teacher hidden states
        ws: [V, D_s]     student unembed weight matrix
        wt: [V, D_t]     teacher unembed weight matrix
        temperature: divisor applied to logits before softmax (default 1.0)
        reduction: "none" -> [B, T] | "mean" / "sum" -> scalar (default "none")
        chunk_V: vocab chunk size controlling peak memory (default 4096)

    Returns:
        KL divergence in float32. Shape depends on reduction.
    """
    assert xs.ndim == 3, f"xs must be [B, T, D_s], got shape {xs.shape}"
    assert xt.ndim == 3, f"xt must be [B, T, D_t], got shape {xt.shape}"
    assert xs.shape[:2] == xt.shape[:2], (
        f"Batch/time dims must match: xs {xs.shape[:2]} vs xt {xt.shape[:2]}"
    )
    assert ws.ndim == 2 and wt.ndim == 2, (
        f"Weight matrices must be [V, D]: ws {ws.shape}, wt {wt.shape}"
    )
    assert ws.shape[0] == wt.shape[0], (
        f"Vocab size must match: ws {ws.shape[0]} vs wt {wt.shape[0]}"
    )
    assert reduction in ("none", "mean", "sum"), (
        f"reduction must be 'none', 'mean', or 'sum'; got {reduction!r}"
    )
    return _ForwardKL.apply(xs, xt, ws, wt, temperature, reduction, chunk_V)


def reverse_kl(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float = 1.0,
    reduction: str = "none",
    chunk_V: int = 4096,
) -> torch.Tensor:
    """KL(p ‖ q)

    Computes the full-vocabulary reverse KL divergence without materializing
    [B, T, V] logit tensors. Memory is O(B*T*chunk_V) per chunk iteration.

    Gradients flow through xs (student hidden states) and ws (student unembed)
    only. Teacher tensors xt and wt are treated as constants.

    Args:
        xs: [B, T, D_s]  student hidden states
        xt: [B, T, D_t]  teacher hidden states
        ws: [V, D_s]     student unembed weight matrix
        wt: [V, D_t]     teacher unembed weight matrix
        temperature: divisor applied to logits before softmax (default 1.0)
        reduction: "none" -> [B, T] | "mean" / "sum" -> scalar (default "none")
        chunk_V: vocab chunk size controlling peak memory (default 4096)

    Returns:
        KL divergence in float32. Shape depends on reduction.
    """
    assert xs.ndim == 3, f"xs must be [B, T, D_s], got shape {xs.shape}"
    assert xt.ndim == 3, f"xt must be [B, T, D_t], got shape {xt.shape}"
    assert xs.shape[:2] == xt.shape[:2], (
        f"Batch/time dims must match: xs {xs.shape[:2]} vs xt {xt.shape[:2]}"
    )
    assert ws.ndim == 2 and wt.ndim == 2, (
        f"Weight matrices must be [V, D]: ws {ws.shape}, wt {wt.shape}"
    )
    assert ws.shape[0] == wt.shape[0], (
        f"Vocab size must match: ws {ws.shape[0]} vs wt {wt.shape[0]}"
    )
    assert reduction in ("none", "mean", "sum"), (
        f"reduction must be 'none', 'mean', or 'sum'; got {reduction!r}"
    )
    return _ReverseKL.apply(xs, xt, ws, wt, temperature, reduction, chunk_V)
