#!/usr/bin/env python3
# Copyright 2026 Tilde Research
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Benchmark Nitrobrew vs naive (materialize-full-logits) KL divergence.

Sweeps over sequence lengths and model dimensions, measuring wall-clock time
and peak GPU memory for both forward and backward passes.

Usage:
    python benchmark.py
"""

import argparse
import csv
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass

import torch

from nitrobrew import forward_kl, reverse_kl


# ---------------------------------------------------------------------------
# Naive baseline
# ---------------------------------------------------------------------------

def naive_forward_kl(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float = 1.0,
) -> torch.Tensor:
    """KL(q ‖ p) via full logit materialization. Reference only — OOMs at scale."""
    B, T, D_s = xs.shape
    zp = torch.mm(xs.view(-1, D_s), ws.T).float() / temperature  # [N, V]
    zq = torch.mm(xt.view(-1, xt.shape[-1]), wt.T).float() / temperature
    log_p = zp.log_softmax(dim=-1)
    log_q = zq.log_softmax(dim=-1)
    q = log_q.exp()
    kl = (q * (log_q - log_p)).sum(dim=-1)
    return kl.view(B, T)


def naive_reverse_kl(
    xs: torch.Tensor,
    xt: torch.Tensor,
    ws: torch.Tensor,
    wt: torch.Tensor,
    temperature: float = 1.0,
) -> torch.Tensor:
    """KL(p ‖ q) via full logit materialization. Reference only — OOMs at scale."""
    B, T, D_s = xs.shape
    zp = torch.mm(xs.view(-1, D_s), ws.T).float() / temperature  # [N, V]
    zq = torch.mm(xt.view(-1, xt.shape[-1]), wt.T).float() / temperature
    log_p = zp.log_softmax(dim=-1)
    log_q = zq.log_softmax(dim=-1)
    p = log_p.exp()
    kl = (p * (log_p - log_q)).sum(dim=-1)
    return kl.view(B, T)


# ---------------------------------------------------------------------------
# Measurement utilities
# ---------------------------------------------------------------------------

@dataclass
class BenchResult:
    method: str
    kl_direction: str
    seq_len: int
    d_model: int
    vocab: int
    fwd_ms: float
    bwd_ms: float
    peak_mb: float
    status: str 


@contextmanager
def track_memory():
    """Context manager that resets peak memory stats and yields a callable to read them."""
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    yield
    torch.cuda.synchronize()


def measure_peak_mb() -> float:
    return torch.cuda.max_memory_allocated() / (1024 * 1024)


def timed_forward_backward(fn, *args, warmup: int = 3, repeats: int = 10):
    """Time forward + backward, return (fwd_ms, bwd_ms) averaged over repeats."""
    for _ in range(warmup):
        out = fn(*args)
        if out.ndim == 0:
            out.backward()
        else:
            out.sum().backward()

    torch.cuda.synchronize()
    fwd_times = []
    bwd_times = []

    for _ in range(repeats):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        out = fn(*args)
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        if out.ndim == 0:
            out.backward()
        else:
            out.sum().backward()
        torch.cuda.synchronize()
        t2 = time.perf_counter()
        fwd_times.append((t1 - t0) * 1000)
        bwd_times.append((t2 - t1) * 1000)

    return sum(fwd_times) / len(fwd_times), sum(bwd_times) / len(bwd_times)


def run_single(
    method: str,
    kl_dir: str,
    B: int,
    T: int,
    D_s: int,
    D_t: int,
    V: int,
    chunk_V: int,
    warmup: int,
    repeats: int,
) -> BenchResult:
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()

    xs = torch.randn(B, T, D_s, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    xt = torch.randn(B, T, D_t, device="cuda", dtype=torch.bfloat16)
    ws = torch.randn(V, D_s, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    wt = torch.randn(V, D_t, device="cuda", dtype=torch.bfloat16)

    if method == "nitrobrew":
        fn = forward_kl if kl_dir == "forward" else reverse_kl
        call = lambda: fn(xs, xt, ws, wt, temperature=1.0, reduction="none", chunk_V=chunk_V)
    else:
        fn = naive_forward_kl if kl_dir == "forward" else naive_reverse_kl
        call = lambda: fn(xs, xt, ws, wt, temperature=1.0)

    try:
        fwd_ms, bwd_ms = timed_forward_backward(call, warmup=warmup, repeats=repeats)
        with track_memory():
            out = call()
            if out.ndim == 0:
                out.backward()
            else:
                out.sum().backward()
        peak_mb = measure_peak_mb()
        status = "ok"
    except torch.cuda.OutOfMemoryError:
        torch.cuda.empty_cache()
        fwd_ms, bwd_ms, peak_mb = float("nan"), float("nan"), float("nan")
        status = "oom"

    del xs, xt, ws, wt
    torch.cuda.empty_cache()

    return BenchResult(
        method=method,
        kl_direction=kl_dir,
        seq_len=B * T,
        d_model=D_s,
        vocab=V,
        fwd_ms=fwd_ms,
        bwd_ms=bwd_ms,
        peak_mb=peak_mb,
        status=status,
    )

def main():
    parser = argparse.ArgumentParser(description="Benchmark Nitrobrew vs naive KL")
    parser.add_argument("--vocab", type=int, default=152064, help="Vocabulary size")
    parser.add_argument("--batch", type=int, default=1, help="Batch size")
    parser.add_argument("--chunk-v", type=int, default=4096, help="Nitrobrew chunk_V")
    parser.add_argument("--warmup", type=int, default=3, help="Warmup iterations")
    parser.add_argument("--repeats", type=int, default=10, help="Timed iterations")
    parser.add_argument("--csv", type=str, default=None, help="Save results to CSV")
    parser.add_argument(
        "--seq-lens", type=int, nargs="+",
        default=[512, 1024, 2048, 4096, 8192],
        help="Sequence lengths to sweep",
    )
    parser.add_argument(
        "--d-models", type=int, nargs="+",
        default=[2048, 3584, 5120],
        help="Model dimensions to sweep (used for both student and teacher)",
    )
    args = parser.parse_args()

    assert torch.cuda.is_available(), "CUDA required for benchmarking"

    device_name = torch.cuda.get_device_name(0)
    total_mem_gb = torch.cuda.get_device_properties(0).total_mem / (1024**3)
    print(f"Device: {device_name} ({total_mem_gb:.1f} GB)")
    print(f"Vocab: {args.vocab}, chunk_V: {args.chunk_v}")
    print(f"Seq lens: {args.seq_lens}")
    print(f"D models: {args.d_models}")
    print()

    results: list[BenchResult] = []

    header = f"{'Method':<12} {'KL':<8} {'SeqLen':>7} {'D':>5} {'V':>7} {'Fwd(ms)':>9} {'Bwd(ms)':>9} {'Peak(MB)':>10} {'Status':<5}"
    print(header)
    print("-" * len(header))

    for d_model in args.d_models:
        for seq_len in args.seq_lens:
            T = seq_len
            B = args.batch

            for kl_dir in ["forward", "reverse"]:
                for method in ["naive", "nitrobrew"]:
                    r = run_single(
                        method=method,
                        kl_dir=kl_dir,
                        B=B, T=T, D_s=d_model, D_t=d_model, V=args.vocab,
                        chunk_V=args.chunk_v,
                        warmup=args.warmup,
                        repeats=args.repeats,
                    )
                    results.append(r)

                    fwd_str = f"{r.fwd_ms:9.2f}" if r.status == "ok" else f"{'—':>9}"
                    bwd_str = f"{r.bwd_ms:9.2f}" if r.status == "ok" else f"{'—':>9}"
                    mem_str = f"{r.peak_mb:10.1f}" if r.status == "ok" else f"{'OOM':>10}"
                    print(
                        f"{r.method:<12} {r.kl_direction:<8} {r.seq_len:>7} "
                        f"{r.d_model:>5} {r.vocab:>7} {fwd_str} {bwd_str} {mem_str} {r.status:<5}"
                    )

                print()

    if args.csv:
        with open(args.csv, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "method", "kl_direction", "seq_len", "d_model", "vocab",
                "fwd_ms", "bwd_ms", "peak_mb", "status",
            ])
            for r in results:
                writer.writerow([
                    r.method, r.kl_direction, r.seq_len, r.d_model, r.vocab,
                    r.fwd_ms, r.bwd_ms, r.peak_mb, r.status,
                ])
        print(f"\nResults saved to {args.csv}")


if __name__ == "__main__":
    main()
